This page is to track progress and features to be introduced within app


# 1: ArticlesListPage.jsx
    * Tiles: Reduce width and increase tiles height
    * 


# 2: ArticlesListPage.jsx
    * Tagging
    * Save Articles - tiles based
    * Add content


# Name: Foresight WIKI

# Debouncing
# Loading
# REDUX
# API calls
