const AboutPage = () => {
    return (
        <>
        <h1 className='mb-4 text-2xl md:text-3xl text-coolGray-900 font-bold text-left'>About Me</h1>
        <p>
            Welcome to How to do app! 
        </p>
    </>
    );

};

export default AboutPage;