const NotFoundPage = () =>{
    return (
        <h1 className='font-bold tracking-light leading-tight md:text-1xl lg:text-3xl'>404: Page Not Found</h1>
    )
}

export default NotFoundPage;